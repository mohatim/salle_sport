package application;

import java.sql.SQLException;

import dao.AdherentDaoImplementation;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.Adherent;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root =FXMLLoader.load(getClass().getResource("/Interfaces/Adherent.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setTitle("Gym & Fitness Center" );
            primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();// e contient les informations sur les exeptions declanch�s & pour afficher l'erreur
		}
	}
	
	public static void main(String[] args) throws SQLException {
		launch(args);
	}
}