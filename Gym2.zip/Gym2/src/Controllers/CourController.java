package Controllers;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import dao.CoachDaoImplementation;
import dao.CourDao;
import dao.CourDaoImplementation;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Coach;
import models.Cour;

public class CourController implements Initializable {

	@FXML
	private TableView<Cour> tableViewCour;
	
	@FXML
	private TableColumn<Cour, String> nomCour;

	@FXML
	private TableColumn<Cour, String> dateDAnimation;
	
	private CourDao courDao;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		nomCour.setCellValueFactory(new PropertyValueFactory<Cour, String>("nomCour"));
		dateDAnimation.setCellValueFactory(new PropertyValueFactory<Cour, String>("dateAnimation"));
		tableViewCour.getItems().setAll(parserCourList());
		
	}

	private List<Cour> parserCourList() {
		try {
			courDao = new CourDaoImplementation();
			return courDao.getAllCours();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
