package Controllers;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import dao.CoachDao;
import dao.CoachDaoImplementation;
import dao.ReservationDaoImplementation;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Coach;
import models.Reservation;

public class CoachController implements Initializable  {

	@FXML
	private TableView<Coach> tableViewCoach;
	
	@FXML
	private TableColumn<Coach, String> nomComplet;
	
	@FXML
	private TableColumn<Coach, String> adresse;

	@FXML
	private TableColumn<Coach, String> email;

	@FXML
	private TableColumn<Coach, String> telephone;

	@FXML
	private TableColumn<Coach, String> nomCour;

	@FXML
	private TableColumn<Coach, String> salaire;
	
	private CoachDao coachDao;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		nomComplet.setCellValueFactory(new PropertyValueFactory<Coach, String>("nomComplet"));
		adresse.setCellValueFactory(new PropertyValueFactory<Coach, String>("adresse"));
		email.setCellValueFactory(new PropertyValueFactory<Coach, String>("telephone"));
		telephone.setCellValueFactory(new PropertyValueFactory<Coach, String>("email"));
		nomCour.setCellValueFactory(new PropertyValueFactory<Coach, String>("nomCour"));
		salaire.setCellValueFactory(new PropertyValueFactory<Coach, String>("salaire"));
		tableViewCoach.getItems().setAll(parserCoachList());
	}


	private List<Coach> parserCoachList() {
		try {
			coachDao = new CoachDaoImplementation();
			return coachDao.getAllCoachs();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	

}
