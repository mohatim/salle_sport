package Controllers;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import dao.AdherentDao;
import dao.AdherentDaoImplementation;
import javafx.application.Application;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Adherent;

public class AdherentController implements Initializable{

	
	@FXML
	private TableView<Adherent> tableViewAdherent;
	
	@FXML
	private TableColumn<Adherent, String> numAdhesion;

	@FXML
	private TableColumn<Adherent, String> nomComplet;

	@FXML
	private TableColumn<Adherent, String> dateDeNaissance;

	@FXML
	private TableColumn<Adherent, String> adresse;

	@FXML
	private TableColumn<Adherent, String> email;

	@FXML
	private TableColumn<Adherent, String> telephone;
	
	private AdherentDao adherentDao= new AdherentDaoImplementation();;

	private List<Adherent> parserAdherentList() {
		try {
			return adherentDao.getAllAdherents();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		numAdhesion.setCellValueFactory(new PropertyValueFactory<Adherent, String>("id"));
		nomComplet.setCellValueFactory(new PropertyValueFactory<Adherent, String>("nomComplet"));
		dateDeNaissance.setCellValueFactory(new PropertyValueFactory<Adherent, String>("dateDeNaissance"));
		adresse.setCellValueFactory(new PropertyValueFactory<Adherent, String>("adresse"));
		email.setCellValueFactory(new PropertyValueFactory<Adherent, String>("mail"));
		telephone.setCellValueFactory(new PropertyValueFactory<Adherent, String>("telephone"));
		tableViewAdherent.getItems().setAll(parserAdherentList());
		
	}
	
	@FXML
    void supprimmerAdherent() {
		TableViewSelectionModel<Adherent> selectionModel = tableViewAdherent.getSelectionModel();
		ObservableList<Adherent> selectedItems = selectionModel.getSelectedItems();
		selectedItems.forEach(adherent ->{
			try {
				adherentDao.deleteAdherent(adherent.getId().intValue());
				tableViewAdherent.getItems().setAll(parserAdherentList());
			} catch (SQLException e) {
				e.printStackTrace();
			}
		});
		
	}
 
}
