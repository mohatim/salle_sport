package Controllers;

import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import dao.AdherentDaoImplementation;
import dao.ReservationDao;
import dao.ReservationDaoImplementation;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Adherent;
import models.Reservation;

public class ReservationsController implements Initializable {
	
	@FXML
	private TableView<Reservation> tableViewReservations;
	
	@FXML
	private TableColumn<Reservation, String> numAdhesion;

	@FXML
	private TableColumn<Reservation, String> nomComplet;

	@FXML
	private TableColumn<Reservation, String> dateDeReservation;

	@FXML
	private TableColumn<Reservation, String> cour;
	
	private ReservationDao reservationDao;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		numAdhesion.setCellValueFactory(new PropertyValueFactory<Reservation, String>("idAdherent"));
		nomComplet.setCellValueFactory(new PropertyValueFactory<Reservation, String>("nomComplet"));
		dateDeReservation.setCellValueFactory(new PropertyValueFactory<Reservation, String>("dateReservation"));
		cour.setCellValueFactory(new PropertyValueFactory<Reservation, String>("nomCour"));
		tableViewReservations.getItems().setAll(parserReservationList());
	}
	
	private List<Reservation> parserReservationList() {
		try {
			reservationDao = new ReservationDaoImplementation();
			return reservationDao.getAllReservations();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}


}
