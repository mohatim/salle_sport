package models;

import java.io.Serializable;
import java.util.Date;

public class Reservation implements Serializable{

	private static final long serialVersionUID = -5161403035117350470L;

	private Long numeroReservation;
	
	private Date dateReservation;
	
	private int nombreHeure;
	
	private Cour cour;
	
	private Adherent adherent;

	public Long getNumeroReservation() {
		return numeroReservation;
	}

	public void setNumeroReservation(Long numeroReservation) {
		this.numeroReservation = numeroReservation;
	}

	public Date getDateReservation() {
		return dateReservation;
	}

	public void setDateReservation(Date dateReservation) {
		this.dateReservation = dateReservation;
	}

	public int getNombreHeure() {
		return nombreHeure;
	}

	public void setNombreHeure(int nombreHeure) {
		this.nombreHeure = nombreHeure;
	}

	public String getNomCour() {
		if(this.cour != null) {
			return this.cour.getNomCour();
		}
		return null;
	}

	public Cour getCour() {
		return cour;
	}

	public void setCour(Cour cour) {
		this.cour = cour;
	}

	public Adherent getAdherent() {
		return adherent;
	}

	public void setAdherent(Adherent adherent) {
		this.adherent = adherent;
	}
	
	public String getNomComplet() {
		return this.adherent.getNomComplet();
	}
	
	public Long getIdAdherent() {
		return this.adherent.getId();
	}
	
}
