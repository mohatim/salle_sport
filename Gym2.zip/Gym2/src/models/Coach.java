package models;

import java.io.Serializable;
import java.util.List;

public class Coach implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2430839761362847435L;

	private Long id;
	
	private String nom;
	
	private String prenom;
	
	private String adresse;
	
	private String telephone;
	
	private String email;
	
	private List<Cour> cours;
	
	private String nomComplet;
	
	private Double salaire;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Cour> getCours() {
		return cours;
	}

	public void setCours(List<Cour> cours) {
		this.cours = cours;
	}
	
	public String getNomComplet() {
		return  nom + " "+ prenom;
	}

	public Double getSalaire() {
		return salaire;
	}

	public void setSalaire(Double salaire) {
		this.salaire = salaire;
	}	
	
	
}
