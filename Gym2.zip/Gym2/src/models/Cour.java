package models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Cour implements Serializable{

	private static final long serialVersionUID = -4479859404649319497L;
	
	private Long id;
	
	private String nomCour;
	
	private List<Adherent> adherents;
	
	private Coach coach;
	
	private Date dateAnimation;
	
	private List<Reservation> reservations;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomCour() {
		return nomCour;
	}

	public void setNomCour(String nomCour) {
		this.nomCour = nomCour;
	}

	public List<Adherent> getAdherents() {
		return adherents;
	}

	public void setAdherents(List<Adherent> adherents) {
		this.adherents = adherents;
	}

	public Coach getCoach() {
		return coach;
	}

	public void setCoach(Coach coach) {
		this.coach = coach;
	}

	public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}

	public Date getDateAnimation() {
		return dateAnimation;
	}

	public void setDateAnimation(Date dateAnimation) {
		this.dateAnimation = dateAnimation;
	}

	
}
