package models;

import java.io.Serializable;

public class Paiement implements Serializable{

	private static final long serialVersionUID = 4292332671890193160L;

	private Double prix;
	
	private Double restePayer;


	public Double getPrix() {
		return prix;
	}

	public void setPrix(Double prix) {
		this.prix = prix;
	}

	public Double getRestePayer() {
		return restePayer;
	}

	public void setRestePayer(Double restePayer) {
		this.restePayer = restePayer;
	}
	
	
	
	

}
