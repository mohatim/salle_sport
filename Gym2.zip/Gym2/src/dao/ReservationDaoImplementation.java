package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.DatabaseConnection;
import models.Adherent;
import models.Cour;
import models.Reservation;

public class ReservationDaoImplementation implements ReservationDao{

	static Connection connection = DatabaseConnection.getConnection();
	
	private AdherentDao adherentDao = new AdherentDaoImplementation();
	
	private CourDao courDao = new CourDaoImplementation();
	
	@Override
	public int addReservation(Reservation reservation, int idAdherent, int idCour) throws SQLException {
		String query
        = "insert into reservation(date_reservation, "
          + " nbr_heure_reservation,id_adherent,id_cour) VALUES (?, ?, ?, ?)";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setDate(1, new Date(reservation.getDateReservation().getTime()));
		ps.setInt(2, reservation.getNombreHeure());
		ps.setInt(3, idAdherent);
		ps.setInt(4, idCour);
		int n = ps.executeUpdate();
		return n;
	}

	@Override
	public void deleteReservation(int id) throws SQLException {
		String query = "delete from reservation where id_reservation =?";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
	}

	@Override
	public Reservation getReservation(int id) throws SQLException {
		String query
        = "select * from reservation where id_reservation= ?";
		PreparedStatement ps
			= connection.prepareStatement(query);

		ps.setInt(1, id);
		Reservation reservation = new Reservation();
		ResultSet rs = ps.executeQuery();
		boolean check = false;

		while (rs.next()) {
			check = true;
			reservation.setNumeroReservation(rs.getLong("id_reservation"));
			reservation.setDateReservation(rs.getDate("date_reservation"));
			reservation.setNombreHeure(rs.getInt("nbr_heure_reservation"));
			int idAdherent = rs.getInt("id_adherent");
			Adherent adherent = adherentDao.getAdherent(idAdherent);
			if(adherent!=null) {
				reservation.setAdherent(adherent);
			}
			int idCour = rs.getInt("id_cour");
			Cour cour = courDao.getCour(idCour);
			if(cour!=null) {
				reservation.setCour(cour);
			}
		}

		if (check) {
			return reservation;
		}
		else
			return null;
	}

	@Override
	public Reservation getReservationsByAdherent(int idAdherent) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reservation> getAllReservations() throws SQLException {
		String query = "select * from reservation";
        PreparedStatement ps
            = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<Reservation> reservations = new ArrayList<>();
  
        while (rs.next()) {
        	Reservation reservation = new Reservation();
			reservation.setNumeroReservation(rs.getLong("id_reservation"));
			reservation.setDateReservation(rs.getDate("date_reservation"));
			reservation.setNombreHeure(rs.getInt("nbr_heure_reservation"));
			int idAdherent = rs.getInt("id_adherent");
			Adherent adherent = adherentDao.getAdherent(idAdherent);
			if(adherent!=null) {
				reservation.setAdherent(adherent);
			}
			int idCour = rs.getInt("id_cour");
			Cour cour = courDao.getCour(idCour);
			if(cour!=null) {
				reservation.setCour(cour);
			}
			reservations.add(reservation);
        }
        return reservations;
	}

	@Override
	public void updateReservation(Reservation reservation) throws SQLException {
		String query
        = "update reservation set date_reservation=?, "
          + " nbr_heure_reservation= ? where id_reservation = ?";
		PreparedStatement ps
			= connection.prepareStatement(query);
		ps.setDate(1, new Date(reservation.getDateReservation().getTime()));
		ps.setInt(2, reservation.getNombreHeure());
		ps.setInt(3, reservation.getNumeroReservation().intValue());
		ps.executeUpdate();
		
	}

}
