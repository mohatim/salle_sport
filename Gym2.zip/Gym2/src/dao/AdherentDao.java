package dao;

import java.sql.SQLException;
import java.util.List;

import models.Adherent;

public interface AdherentDao {

	public int addAdherent(Adherent adherent) throws SQLException;
	
	
	public void deleteAdherent(int id) throws SQLException;
	    
	
	public Adherent getAdherent(int id) throws SQLException;
	    
	
	public List<Adherent> getAllAdherents() throws SQLException;
	    
	
	public void updateAdherent(Adherent adherent) throws SQLException;
}
