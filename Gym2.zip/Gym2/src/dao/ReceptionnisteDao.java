package dao;

import java.sql.SQLException;
import java.util.List;

import models.Receptionniste;
import models.Receptionniste;

public interface ReceptionnisteDao {
	
	public int addReceptionniste(Receptionniste receptionniste) throws SQLException;
	
	
	public void deleteReceptionniste(int id) throws SQLException;
	    
	
	public Receptionniste getReceptionniste(String identifiant, String motDePasse) throws SQLException;
	    
	
	public List<Receptionniste> getAllReceptionnistes() throws SQLException;
	    
	
	public void updateReceptionniste(Receptionniste receptionniste) throws SQLException;
}
