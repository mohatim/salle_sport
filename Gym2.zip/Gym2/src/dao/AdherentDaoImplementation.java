package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.DatabaseConnection;
import models.Adherent;

public class AdherentDaoImplementation implements AdherentDao{
	
	static Connection connection = DatabaseConnection.getConnection();

	@Override
	public int addAdherent(Adherent adherent) throws SQLException {
		String query
        = "insert into adherent(nom_adherent, "
          + "prenom_adherent,mail_adherent) VALUES (?, ?, ?)";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, adherent.getNom());
		ps.setString(2, adherent.getPrenom());
		ps.setString(3, adherent.getMail());
		int n = ps.executeUpdate();
		return n;
	}

	@Override
	public void deleteAdherent(int id) throws SQLException {
		String query = "delete from adherent where id_adherent =?";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
	}

	@Override
	public Adherent getAdherent(int id) throws SQLException {
		String query
        = "select * from adherent where id_adherent= ?";
		PreparedStatement ps
			= connection.prepareStatement(query);

		ps.setInt(1, id);
		Adherent adherent = new Adherent();
		ResultSet rs = ps.executeQuery();
		boolean check = false;

		while (rs.next()) {
        check = true;
        adherent.setId(rs.getLong("id_adherent"));
        adherent.setNom(rs.getString("nom_adherent"));
        adherent.setPrenom(rs.getString("prenom_adherent"));
        adherent.setMail(rs.getString("mail_adherent"));
        adherent.setAdresse(rs.getString("adresse_adherent"));
        adherent.setTelephone(rs.getString("telephone_adherent"));
        if(rs.getDate("date_naissance_adherent")!=null) {
        	adherent.setDateDeNaissance(rs.getDate("date_naissance_adherent"));
        }
		}

		if (check) {
			return adherent;
		}
		else
			return null;
	}

	@Override
	public List<Adherent> getAllAdherents() throws SQLException {
        String query = "select * from adherent";
        PreparedStatement ps
            = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<Adherent> adherents = new ArrayList<>();
  
        while (rs.next()) {
        	Adherent adherent = new Adherent();
            adherent.setId(rs.getLong("id_adherent"));
            adherent.setNom(rs.getString("nom_adherent"));
            adherent.setPrenom(rs.getString("prenom_adherent"));
            adherent.setMail(rs.getString("mail_adherent"));
            adherent.setAdresse(rs.getString("adresse_adherent"));
            adherent.setTelephone(rs.getString("telephone_adherent"));
            if(rs.getDate("date_naissance_adherent")!=null) {
            	adherent.setDateDeNaissance(rs.getDate("date_naissance_adherent"));
            }
            adherents.add(adherent);
        }
        return adherents;
	}

	@Override
	public void updateAdherent(Adherent adherent) throws SQLException {
		String query
        = "update adherent set nom_adherent=?, "
          + " prenom_adherent= ? where id_adherent = ?";
		PreparedStatement ps
			= connection.prepareStatement(query);
		ps.setString(1, adherent.getNom());
		ps.setString(2, adherent.getPrenom());
		ps.setLong(3, adherent.getId());
		ps.executeUpdate();
	}

}
