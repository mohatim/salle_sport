package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.DatabaseConnection;
import models.Adherent;
import models.Coach;
import models.Cour;
import models.Cour;

public class CourDaoImplementation implements CourDao{
	
	static Connection connection = DatabaseConnection.getConnection();
	
	@Override
	public int addCour(Cour cour, int idCoach) throws SQLException {
		String query
        = "insert into cour(nom_cour, "
          + "id_coach) VALUES (?, ?)";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, cour.getNomCour());
		ps.setInt(2, idCoach);
		int n = ps.executeUpdate();
		return n;
	}

	@Override
	public void deleteCour(int id) throws SQLException {
		String query = "delete from cour where id_cour =?";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
		
	}

	@Override
	public Cour getCour(int id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cour> getAllCours() throws SQLException {
		String query = "select * from cour";
        PreparedStatement ps
            = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<Cour> cours = new ArrayList<>();
  
        while (rs.next()) {
        	Cour cour = new Cour();
			cour.setId(rs.getLong("id_cour"));
			cour.setNomCour(rs.getString("nom_cour"));
			cour.setDateAnimation(rs.getDate("date_animation_cour"));
			int idCoach = rs.getInt("id_coach");
			PreparedStatement ps2 = connection.prepareStatement("select * from coach where id_coach= ?");
			ps2.setInt(1, idCoach);
			ResultSet rs2 = ps2.executeQuery();
			if(rs2.next()) {
				Coach coach = new Coach();
	        	coach.setId(rs2.getLong("id_coach"));
	        	coach.setNom(rs2.getString("nom_coach"));
	        	coach.setPrenom(rs2.getString("prenom_coach"));
	        	coach.setAdresse(rs2.getString("adresse_coach"));
	        	coach.setEmail(rs2.getString("email_coach"));
	        	coach.setTelephone(rs2.getString("telephone_coach"));
	            cour.setCoach(coach);
			}
			cours.add(cour);
        }
        return cours;
	}

	@Override
	public void updateCour(Cour cour) throws SQLException {
		String query
        = "update cour set nom_cour=?, date_animation_cour= ? "
          + " where id_cour = ?";
		PreparedStatement ps
			= connection.prepareStatement(query);
		ps.setString(1, cour.getNomCour());
		ps.setDate(2, new Date(cour.getDateAnimation().getTime()));
		ps.setLong(3, cour.getId());
		ps.executeUpdate();
	}

}
