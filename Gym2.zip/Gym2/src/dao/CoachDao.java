package dao;

import java.sql.SQLException;
import java.util.List;

import models.Coach;

public interface CoachDao {

	public int addCoach(Coach coach) throws SQLException;
	
	
	public void deleteCoach(int id) throws SQLException;
	    
	
	public Coach getCoach(int id) throws SQLException;
	    
	
	public List<Coach> getAllCoachs() throws SQLException;
	    
	
	public void updateCoach(Coach coach) throws SQLException;
}
