package dao;

import java.sql.SQLException;
import java.util.List;

import models.Reservation;

public interface ReservationDao {

	public int addReservation(Reservation reservation, int idAdherent, int idCour) throws SQLException;
	
	
	public void deleteReservation(int id) throws SQLException;
	    
	
	public Reservation getReservation(int id) throws SQLException;
	
	public Reservation getReservationsByAdherent(int idAdherent) throws SQLException;
	    
	
	public List<Reservation> getAllReservations() throws SQLException;
	    
	
	public void updateReservation(Reservation reservation) throws SQLException;
}
