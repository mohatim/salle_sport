package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.DatabaseConnection;
import models.Adherent;
import models.Receptionniste;

public class ReceptionnisteDaoImplementation implements ReceptionnisteDao{

	static Connection connection = DatabaseConnection.getConnection();
	
	@Override
	public int addReceptionniste(Receptionniste receptionniste) throws SQLException {
		String query
        = "insert into receptionniste(identifiant_recep, "
          + "nom_recep,prenom_recep,password_recep,mail_recep) VALUES (?, ?, ?, ?, ?)";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, receptionniste.getIdentifiant());
		ps.setString(2, receptionniste.getNom());
		ps.setString(3, receptionniste.getPrenom());
		ps.setString(4, receptionniste.getMotDePasse());
		ps.setString(5, receptionniste.getMail());
		int n = ps.executeUpdate();
		return n;
	}

	@Override
	public void deleteReceptionniste(int id) throws SQLException {
		String query = "delete from receptionniste where id_recep =?";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
	}

	@Override
	public Receptionniste getReceptionniste(String identifiant, String motDePasse) throws SQLException {
		String query
        = "select * from receptionniste where identifiant_recep = ? and password_recep = ?";
		PreparedStatement ps
			= connection.prepareStatement(query);

		ps.setString(1, identifiant);
		ps.setString(2, motDePasse);
		Receptionniste receptionniste = new Receptionniste();
		ResultSet rs = ps.executeQuery();
		boolean check = false;

		while (rs.next()) {
        check = true;
        receptionniste.setId(rs.getLong("id_recep"));
        receptionniste.setIdentifiant(rs.getString("identifiant_recep"));
        receptionniste.setNom(rs.getString("nom_recep"));
        receptionniste.setPrenom(rs.getString("prenom_recep"));
        receptionniste.setMotDePasse(rs.getString("password_recep"));
        receptionniste.setMail(rs.getString("mail_recep"));
		}

		if (check) {
			return receptionniste;
		}
		else
			return null;
	}

	@Override
	public List<Receptionniste> getAllReceptionnistes() throws SQLException {
		String query = "select * from receptionniste";
        PreparedStatement ps
            = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<Receptionniste> receptionnistes = new ArrayList<>();
  
        while (rs.next()) {
        	Receptionniste receptionniste = new Receptionniste();
        	receptionniste.setId(rs.getLong("id_recep"));
        	receptionniste.setIdentifiant(rs.getString("identifiant_recep"));
        	receptionniste.setNom(rs.getString("nom_recep"));
        	receptionniste.setPrenom(rs.getString("prenom_recep"));
        	receptionniste.setMotDePasse(rs.getString("password_recep"));
        	receptionniste.setMail(rs.getString("mail_recep"));
            receptionnistes.add(receptionniste);
        }
        return receptionnistes;
	}

	@Override
	public void updateReceptionniste(Receptionniste receptionniste) throws SQLException {
		String query
        = "update receptionniste set identifiant_recep=? "
          + " password_recep= ? where id_recep = ?";
		PreparedStatement ps
			= connection.prepareStatement(query);
		ps.setString(1, receptionniste.getIdentifiant());
		ps.setString(2, receptionniste.getMotDePasse());
		ps.setLong(3, receptionniste.getId());
		ps.executeUpdate();
	}



}
