package dao;

import java.sql.SQLException;
import java.util.List;

import models.Coach;
import models.Cour;

public interface CourDao {
	
	public int addCour(Cour cour, int idCoach) throws SQLException;

	public void deleteCour(int id) throws SQLException;
	    
	
	public Cour getCour(int id) throws SQLException;
	    
	
	public List<Cour> getAllCours() throws SQLException;
	    
	
	public void updateCour(Cour cour) throws SQLException;
}
