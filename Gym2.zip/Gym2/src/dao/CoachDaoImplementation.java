package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import application.DatabaseConnection;
import models.Adherent;
import models.Coach;
import models.Cour;
import models.Reservation;

public class CoachDaoImplementation implements CoachDao{

	static Connection connection = DatabaseConnection.getConnection();
	
	@Override
	public int addCoach(Coach coach) throws SQLException {
		String query
        = "insert into coach(nom_coach, "
          + "prenom_coach,adresse_coach, email_coach,telephone_coach) VALUES (?, ?, ?, ?, ?)";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, coach.getNom());
		ps.setString(2, coach.getPrenom());
		ps.setString(3, coach.getAdresse());
		ps.setString(4, coach.getEmail());
		ps.setString(5, coach.getTelephone());
		int n = ps.executeUpdate();
		return n;
	}

	@Override
	public void deleteCoach(int id) throws SQLException {
		String query = "delete from coach where id_coach =?";
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
	}

	@Override
	public Coach getCoach(int id) throws SQLException {
		String query
        = "select * from coach where id_coach= ?";
		PreparedStatement ps
			= connection.prepareStatement(query);

		ps.setInt(1, id);
		Coach coach = new Coach();
		ResultSet rs = ps.executeQuery();
		boolean check = false;

		while (rs.next()) {
			check = true;
			coach.setId(rs.getLong("id_coach"));
        	coach.setNom(rs.getString("nom_coach"));
        	coach.setPrenom(rs.getString("prenom_coach"));
        	coach.setAdresse(rs.getString("adresse_coach"));
        	coach.setEmail(rs.getString("email_coach"));
        	coach.setTelephone(rs.getString("telephone_coach"));
			
		}

		if (check) {
			return coach;
		}
		else
			return null;
	}

	@Override
	public List<Coach> getAllCoachs() throws SQLException {
		String query = "select * from coach";
        PreparedStatement ps
            = connection.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<Coach> coachs = new ArrayList<>();
  
        while (rs.next()) {
        	Coach coach = new Coach();
        	coach.setId(rs.getLong("id_coach"));
        	coach.setNom(rs.getString("nom_coach"));
        	coach.setPrenom(rs.getString("prenom_coach"));
        	coach.setAdresse(rs.getString("adresse_coach"));
        	coach.setEmail(rs.getString("email_coach"));
        	coach.setTelephone(rs.getString("telephone_coach"));
            
            coachs.add(coach);
        }
        return coachs;
	}

	@Override
	public void updateCoach(Coach coach) throws SQLException {
		String query
        = "update coach set nom_coach=?, "
          + " prenom_coach = ?, adresse_coach = ?, email_coach = ?,  telephone_coach = ? where id_adherent = ?";
		PreparedStatement ps
			= connection.prepareStatement(query);
		ps.setString(1, coach.getNom());
		ps.setString(2, coach.getPrenom());
		ps.setString(3, coach.getAdresse());
		ps.setString(4, coach.getEmail());
		ps.setString(5, coach.getTelephone());
		ps.setLong(6, coach.getId());
		ps.executeUpdate();
		
	}

	
}
