
module Gym2 {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	requires java.sql;
	requires javafx.base;
//	requires mysql.connector.java;
//	exports mon.package.principal;  
//	   requires javafx.fxml;
//	   opens mon.package.contenant.des.fichiers.fxml to javafx.fxml;
	

    opens models to javafx.fxml;
//    opens models.Adherent to javafx.fxml;

    exports models;
//    exports models.Adherent;
//	
	
	opens application;
	opens Controllers;
}
